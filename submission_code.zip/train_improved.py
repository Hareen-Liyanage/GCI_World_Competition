import os
import sys
import gc
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import catboost as cb
import xgboost as xgb

warnings.filterwarnings('ignore')

print("Starting Enhanced Feature Engineering and Training Pipeline...")

ROOT = Path.cwd()
train_path = ROOT / 'input' / 'train.csv'
test_path  = ROOT / 'input' / 'test.csv'
sub_path   = ROOT / 'input' / 'sample_submission.csv'

train = pd.read_csv(train_path)
test  = pd.read_csv(test_path)
sample_sub = pd.read_csv(sub_path)

y = train['TARGET'].values
train_ids = train['SK_ID_CURR'].values
test_ids  = test['SK_ID_CURR'].values

print(f"Train shape: {train.shape}, Test shape: {test.shape}, Target mean: {y.mean():.4f}")

# 1. Base cleanings
for df in [train, test]:
    df['DAYS_EMPLOYED_ANOM'] = (df['DAYS_EMPLOYED'] == 365243).astype(int)
    df['DAYS_EMPLOYED_CLEAN'] = df['DAYS_EMPLOYED'].replace(365243, np.nan)
    
    # Financial Ratios
    df['PAYMENT_RATE'] = df['AMT_ANNUITY'] / (df['AMT_CREDIT'] + 1.0)
    df['CREDIT_INCOME_RATIO'] = df['AMT_CREDIT'] / (df['AMT_INCOME_TOTAL'] + 1.0)
    df['ANNUITY_INCOME_RATIO'] = df['AMT_ANNUITY'] / (df['AMT_INCOME_TOTAL'] + 1.0)
    df['CREDIT_GOODS_RATIO'] = df['AMT_CREDIT'] / (df['AMT_GOODS_PRICE'] + 1.0)
    df['GOODS_CREDIT_DIFF'] = df['AMT_GOODS_PRICE'] - df['AMT_CREDIT']
    df['INCOME_CREDIT_DIFF'] = df['AMT_INCOME_TOTAL'] - df['AMT_CREDIT']
    df['DISPOSABLE_INCOME'] = df['AMT_INCOME_TOTAL'] - df['AMT_ANNUITY']
    
    # Per-person ratios
    df['INCOME_PER_PERSON'] = df['AMT_INCOME_TOTAL'] / (df['CNT_FAM_MEMBERS'] + 1.0)
    df['CREDIT_PER_PERSON'] = df['AMT_CREDIT'] / (df['CNT_FAM_MEMBERS'] + 1.0)
    df['ANNUITY_PER_PERSON'] = df['AMT_ANNUITY'] / (df['CNT_FAM_MEMBERS'] + 1.0)
    df['INCOME_PER_CHILD'] = df['AMT_INCOME_TOTAL'] / (df['CNT_CHILDREN'] + 1.0)
    df['ADULTS_COUNT'] = np.maximum(1.0, df['CNT_FAM_MEMBERS'] - df['CNT_CHILDREN'])
    df['INCOME_PER_ADULT'] = df['AMT_INCOME_TOTAL'] / df['ADULTS_COUNT']
    
    # Demographic & Time ratios
    df['AGE_YEARS'] = -df['DAYS_BIRTH'] / 365.25
    df['EMPLOYED_YEARS'] = -df['DAYS_EMPLOYED_CLEAN'] / 365.25
    df['EMPLOYED_TO_BIRTH_RATIO'] = df['DAYS_EMPLOYED_CLEAN'] / (df['DAYS_BIRTH'] - 1.0)
    df['ID_TO_BIRTH_RATIO'] = df['DAYS_ID_PUBLISH'] / (df['DAYS_BIRTH'] - 1.0)
    df['REG_TO_BIRTH_RATIO'] = df['DAYS_REGISTRATION'] / (df['DAYS_BIRTH'] - 1.0)
    df['PHONE_TO_BIRTH_RATIO'] = df['DAYS_LAST_PHONE_CHANGE'] / (df['DAYS_BIRTH'] - 1.0)
    df['PHONE_TO_EMPLOYED_RATIO'] = df['DAYS_LAST_PHONE_CHANGE'] / (df['DAYS_EMPLOYED_CLEAN'] - 1.0)
    df['CAR_TO_BIRTH_RATIO'] = df['OWN_CAR_AGE'] / (df['AGE_YEARS'] + 1.0)
    df['CAR_TO_EMPLOYED_RATIO'] = df['OWN_CAR_AGE'] / (df['EMPLOYED_YEARS'] + 1.0)
    
    # Missing flags
    df['EXT_1_NA'] = df['EXT_SOURCE_1'].isna().astype(int)
    df['EXT_2_NA'] = df['EXT_SOURCE_2'].isna().astype(int)
    df['EXT_3_NA'] = df['EXT_SOURCE_3'].isna().astype(int)
    df['CAR_AGE_NA'] = df['OWN_CAR_AGE'].isna().astype(int)
    df['OCCUPATION_NA'] = df['OCCUPATION_TYPE'].isna().astype(int)
    
    # External Sources Aggregations
    ext_cols = ['EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3']
    df['EXT_SOURCES_MEAN'] = df[ext_cols].mean(axis=1)
    df['EXT_SOURCES_STD']  = df[ext_cols].std(axis=1)
    df['EXT_SOURCES_MIN']  = df[ext_cols].min(axis=1)
    df['EXT_SOURCES_MAX']  = df[ext_cols].max(axis=1)
    df['EXT_SOURCES_SUM']  = df[ext_cols].sum(axis=1)
    df['EXT_SOURCES_COUNT'] = df[ext_cols].notna().sum(axis=1)
    
    # Multiplicative & non-linear
    df['EXT_1_x_2'] = df['EXT_SOURCE_1'] * df['EXT_SOURCE_2']
    df['EXT_2_x_3'] = df['EXT_SOURCE_2'] * df['EXT_SOURCE_3']
    df['EXT_1_x_3'] = df['EXT_SOURCE_1'] * df['EXT_SOURCE_3']
    df['EXT_1_div_2'] = df['EXT_SOURCE_1'] / (df['EXT_SOURCE_2'] + 1e-4)
    df['EXT_2_div_3'] = df['EXT_SOURCE_2'] / (df['EXT_SOURCE_3'] + 1e-4)
    df['EXT_3_div_1'] = df['EXT_SOURCE_3'] / (df['EXT_SOURCE_1'] + 1e-4)
    
    df['EXT_2_SQ'] = df['EXT_SOURCE_2'] ** 2
    df['EXT_3_SQ'] = df['EXT_SOURCE_3'] ** 2
    df['EXT_2_CUBE'] = df['EXT_SOURCE_2'] ** 3
    df['EXT_3_CUBE'] = df['EXT_SOURCE_3'] ** 3
    
    df['EXT_SOURCES_OVER_AGE'] = df['EXT_SOURCES_MEAN'] / (df['AGE_YEARS'] + 1.0)
    df['EXT_2_OVER_AGE'] = df['EXT_SOURCE_2'] / (df['AGE_YEARS'] + 1.0)
    df['EXT_3_OVER_AGE'] = df['EXT_SOURCE_3'] / (df['AGE_YEARS'] + 1.0)
    df['EXT_SOURCE_WEIGHTED'] = (
        df['EXT_SOURCE_1'].fillna(0.5) * 1.5 +
        df['EXT_SOURCE_2'].fillna(0.5) * 3.0 +
        df['EXT_SOURCE_3'].fillna(0.5) * 3.5
    )
    
    # Bureau Ratios
    bureau_cols = [
        'AMT_REQ_CREDIT_BUREAU_HOUR', 'AMT_REQ_CREDIT_BUREAU_MON',
        'AMT_REQ_CREDIT_BUREAU_QRT', 'AMT_REQ_CREDIT_BUREAU_YEAR'
    ]
    df['BUREAU_TOTAL_REQ'] = df[bureau_cols].sum(axis=1)
    df['BUREAU_MON_TO_YEAR'] = df['AMT_REQ_CREDIT_BUREAU_MON'] / (df['AMT_REQ_CREDIT_BUREAU_YEAR'] + 1.0)
    df['BUREAU_QRT_TO_YEAR'] = df['AMT_REQ_CREDIT_BUREAU_QRT'] / (df['AMT_REQ_CREDIT_BUREAU_YEAR'] + 1.0)

# Categorical combinations
for df in [train, test]:
    df['OCC_AND_ORG'] = df['OCCUPATION_TYPE'].astype(str) + '__' + df['ORGANIZATION_TYPE'].astype(str)
    df['EDU_AND_INCOME'] = df['NAME_EDUCATION_TYPE'].astype(str) + '__' + df['NAME_INCOME_TYPE'].astype(str)
    df['GENDER_AND_EDU'] = df['CODE_GENDER'].astype(str) + '__' + df['NAME_EDUCATION_TYPE'].astype(str)

# Group-by Statistics across train & test (mean and std, z-scores)
combined_df = pd.concat([train.drop(columns=['TARGET'], errors='ignore'), test], axis=0).reset_index(drop=True)

group_specs = [
    ('OCCUPATION_TYPE', ['AMT_INCOME_TOTAL', 'AMT_CREDIT', 'EXT_SOURCE_2', 'DAYS_BIRTH']),
    ('ORGANIZATION_TYPE', ['AMT_INCOME_TOTAL', 'AMT_CREDIT', 'PAYMENT_RATE']),
    ('NAME_EDUCATION_TYPE', ['AMT_INCOME_TOTAL', 'EXT_SOURCE_2']),
    ('EDU_AND_INCOME', ['AMT_INCOME_TOTAL', 'AMT_CREDIT']),
]

for grp, cols in group_specs:
    for col in cols:
        stats = combined_df.groupby(grp)[col].agg(['mean', 'std']).reset_index()
        stats.columns = [grp, f'{col}_BY_{grp}_MEAN', f'{col}_BY_{grp}_STD']
        
        train = train.merge(stats, on=grp, how='left')
        test  = test.merge(stats, on=grp, how='left')
        
        for df in [train, test]:
            df[f'{col}_BY_{grp}_DIFF'] = df[col] - df[f'{col}_BY_{grp}_MEAN']
            df[f'{col}_BY_{grp}_RATIO'] = df[col] / (df[f'{col}_BY_{grp}_MEAN'] + 1e-5)
            df[f'{col}_BY_{grp}_ZSCORE'] = (df[col] - df[f'{col}_BY_{grp}_MEAN']) / (df[f'{col}_BY_{grp}_STD'] + 1e-5)

# Frequency (Count) Encoding
count_cols = [
    'ORGANIZATION_TYPE', 'OCCUPATION_TYPE', 'NAME_INCOME_TYPE',
    'NAME_EDUCATION_TYPE', 'OCC_AND_ORG', 'EDU_AND_INCOME', 'GENDER_AND_EDU'
]
for col in count_cols:
    counts = combined_df[col].value_counts().to_dict()
    train[f'{col}_COUNT'] = train[col].map(counts)
    test[f'{col}_COUNT']  = test[col].map(counts)

print("Predictive Imputation of missing EXT_SOURCE_1...")
# Train a LightGBM regressor to predict missing EXT_SOURCE_1
ext1_known_idx = train['EXT_SOURCE_1'].notna()
ext1_predictors = [
    'AMT_INCOME_TOTAL', 'AMT_CREDIT', 'AMT_ANNUITY', 'AMT_GOODS_PRICE',
    'DAYS_BIRTH', 'DAYS_EMPLOYED_CLEAN', 'DAYS_REGISTRATION', 'DAYS_ID_PUBLISH',
    'OWN_CAR_AGE', 'REGION_POPULATION_RELATIVE', 'REGION_RATING_CLIENT',
    'AGE_YEARS', 'PAYMENT_RATE', 'CREDIT_INCOME_RATIO'
]

reg_train_X = train.loc[ext1_known_idx, ext1_predictors]
reg_train_y = train.loc[ext1_known_idx, 'EXT_SOURCE_1']
reg_full_X  = combined_df[ext1_predictors]

reg_model = lgb.LGBMRegressor(
    n_estimators=300,
    learning_rate=0.05,
    num_leaves=31,
    random_state=42,
    n_jobs=-1,
    verbose=-1
)
reg_model.fit(reg_train_X, reg_train_y)
pred_ext1 = reg_model.predict(reg_full_X)

train['EXT_SOURCE_1_PRED'] = pred_ext1[:len(train)]
test['EXT_SOURCE_1_PRED']  = pred_ext1[len(train):]

for df in [train, test]:
    df['EXT_1_IMPUTED'] = df['EXT_SOURCE_1'].fillna(df['EXT_SOURCE_1_PRED'])
    df['EXT_1_IMPUTED_DIFF'] = df['EXT_SOURCE_1'] - df['EXT_SOURCE_1_PRED']

# Encode categoricals using LabelEncoder for tree models
cat_cols = train.select_dtypes(include=['object']).columns.tolist()
for col in cat_cols:
    le = LabelEncoder()
    comb = pd.concat([train[col], test[col]], axis=0).astype(str)
    le.fit(comb)
    train[col] = le.transform(train[col].astype(str))
    test[col]  = le.transform(test[col].astype(str))

# Drop identifiers and target from feature matrices
drop_cols = ['SK_ID_CURR', 'TARGET']
feature_cols = [c for c in train.columns if c not in drop_cols]
X = train[feature_cols].copy()
X_test = test[feature_cols].copy()

print(f"Engineered Feature count: {len(feature_cols)}")

# Leakage-Safe Out-Of-Fold Target Encoding
te_cols = [
    'ORGANIZATION_TYPE', 'OCCUPATION_TYPE', 'NAME_INCOME_TYPE',
    'NAME_EDUCATION_TYPE', 'OCC_AND_ORG', 'EDU_AND_INCOME'
]

def smoothed_target_encoding(reference_categories, reference_target, apply_categories, smoothing=20.0):
    prior = float(np.mean(reference_target))
    stats = pd.DataFrame({
        'category': reference_categories.to_numpy(),
        'target': reference_target
    }).groupby('category')['target'].agg(['sum', 'count'])
    encoded = (stats['sum'] + smoothing * prior) / (stats['count'] + smoothing)
    return apply_categories.map(encoded).fillna(prior).to_numpy(dtype=float)

N_FOLDS = 5
SEED = 42
skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
fold_indices = list(skf.split(X, y))

# Setup Models
lgb_params = {
    'objective': 'binary',
    'metric': 'auc',
    'boosting_type': 'gbdt',
    'n_estimators': 2500,
    'learning_rate': 0.02,
    'num_leaves': 31,
    'max_depth': -1,
    'min_child_samples': 50,
    'subsample': 0.8,
    'subsample_freq': 1,
    'colsample_bytree': 0.6,
    'reg_alpha': 0.1,
    'reg_lambda': 10.0,
    'random_state': SEED,
    'n_jobs': -1,
    'verbose': -1,
}

lgb_params_deep = {
    'objective': 'binary',
    'metric': 'auc',
    'boosting_type': 'gbdt',
    'n_estimators': 2000,
    'learning_rate': 0.02,
    'num_leaves': 63,
    'max_depth': 7,
    'min_child_samples': 80,
    'subsample': 0.75,
    'subsample_freq': 1,
    'colsample_bytree': 0.5,
    'reg_alpha': 0.5,
    'reg_lambda': 20.0,
    'random_state': SEED + 10,
    'n_jobs': -1,
    'verbose': -1,
}

cat_params = {
    'iterations': 1500,
    'learning_rate': 0.03,
    'depth': 6,
    'eval_metric': 'AUC',
    'l2_leaf_reg': 10.0,
    'random_seed': SEED,
    'verbose': 0,
    'thread_count': -1,
}

xgb_params = {
    'n_estimators': 1500,
    'learning_rate': 0.03,
    'max_depth': 5,
    'min_child_weight': 50,
    'subsample': 0.8,
    'colsample_bytree': 0.6,
    'reg_lambda': 15.0,
    'objective': 'binary:logistic',
    'eval_metric': 'auc',
    'tree_method': 'hist',
    'random_state': SEED,
    'n_jobs': -1,
}

oof_lgb1  = np.zeros(len(X))
test_lgb1 = np.zeros(len(X_test))
oof_lgb2  = np.zeros(len(X))
test_lgb2 = np.zeros(len(X_test))
oof_cat   = np.zeros(len(X))
test_cat  = np.zeros(len(X_test))
oof_xgb   = np.zeros(len(X))
test_xgb  = np.zeros(len(X_test))

print("\n--- Training 5-Fold Stratified Ensemble ---")
for fold, (tr_idx, val_idx) in enumerate(fold_indices, 1):
    print(f"\n>>> Fold {fold}/{N_FOLDS} <<<")
    X_tr_df  = X.iloc[tr_idx].copy().reset_index(drop=True)
    X_val_df = X.iloc[val_idx].copy().reset_index(drop=True)
    X_te_df  = X_test.copy().reset_index(drop=True)
    y_tr, y_val = y[tr_idx], y[val_idx]
    
    # Internal Stratified K-Fold for leakage-free Target Encoding on Train
    inner_skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED + fold)
    te_tr = np.zeros((len(tr_idx), len(te_cols)), dtype=float)
    for inner_tr_idx, inner_val_idx in inner_skf.split(X_tr_df, y_tr):
        for col_idx, col in enumerate(te_cols):
            te_tr[inner_val_idx, col_idx] = smoothed_target_encoding(
                X_tr_df[col].iloc[inner_tr_idx], y_tr[inner_tr_idx],
                X_tr_df[col].iloc[inner_val_idx]
            )
            
    te_val = np.column_stack([
        smoothed_target_encoding(X_tr_df[col], y_tr, X_val_df[col])
        for col in te_cols
    ])
    te_test = np.column_stack([
        smoothed_target_encoding(X_tr_df[col], y_tr, X_te_df[col])
        for col in te_cols
    ])
    
    for c_idx, col in enumerate(te_cols):
        te_col_name = f'{col}_TE'
        X_tr_df[te_col_name]  = te_tr[:, c_idx]
        X_val_df[te_col_name] = te_val[:, c_idx]
        X_te_df[te_col_name]  = te_test[:, c_idx]
        
    X_tr = X_tr_df.values
    X_val = X_val_df.values
    X_te = X_te_df.values
    
    # Model 1: LightGBM (standard)
    m_lgb1 = lgb.LGBMClassifier(**lgb_params)
    m_lgb1.fit(
        X_tr, y_tr,
        eval_set=[(X_val, y_val)],
        callbacks=[lgb.early_stopping(80, verbose=False)]
    )
    p_lgb1 = m_lgb1.predict_proba(X_val)[:, 1]
    oof_lgb1[val_idx] = p_lgb1
    test_lgb1 += m_lgb1.predict_proba(X_te)[:, 1] / N_FOLDS
    print(f"  LGB1 AUC: {roc_auc_score(y_val, p_lgb1):.5f} (best iter {m_lgb1.best_iteration_})")
    
    # Model 2: LightGBM (deep)
    m_lgb2 = lgb.LGBMClassifier(**lgb_params_deep)
    m_lgb2.fit(
        X_tr, y_tr,
        eval_set=[(X_val, y_val)],
        callbacks=[lgb.early_stopping(80, verbose=False)]
    )
    p_lgb2 = m_lgb2.predict_proba(X_val)[:, 1]
    oof_lgb2[val_idx] = p_lgb2
    test_lgb2 += m_lgb2.predict_proba(X_te)[:, 1] / N_FOLDS
    print(f"  LGB2 AUC: {roc_auc_score(y_val, p_lgb2):.5f} (best iter {m_lgb2.best_iteration_})")
    
    # Model 3: CatBoost
    m_cat = cb.CatBoostClassifier(**cat_params)
    m_cat.fit(X_tr, y_tr, eval_set=(X_val, y_val), early_stopping_rounds=70)
    p_cat = m_cat.predict_proba(X_val)[:, 1]
    oof_cat[val_idx] = p_cat
    test_cat += m_cat.predict_proba(X_te)[:, 1] / N_FOLDS
    print(f"  CAT  AUC: {roc_auc_score(y_val, p_cat):.5f}")
    
    # Model 4: XGBoost
    m_xgb = xgb.XGBClassifier(**xgb_params, early_stopping_rounds=80)
    m_xgb.fit(X_tr, y_tr, eval_set=[(X_val, y_val)], verbose=False)
    p_xgb = m_xgb.predict_proba(X_val)[:, 1]
    oof_xgb[val_idx] = p_xgb
    test_xgb += m_xgb.predict_proba(X_te)[:, 1] / N_FOLDS
    print(f"  XGB  AUC: {roc_auc_score(y_val, p_xgb):.5f}")
    
    del m_lgb1, m_lgb2, m_cat, m_xgb, X_tr, X_val, X_te
    gc.collect()

print("\n=== Individual Model OOF AUCs ===")
print(f"LightGBM 1 : {roc_auc_score(y, oof_lgb1):.5f}")
print(f"LightGBM 2 : {roc_auc_score(y, oof_lgb2):.5f}")
print(f"CatBoost   : {roc_auc_score(y, oof_cat):.5f}")
print(f"XGBoost    : {roc_auc_score(y, oof_xgb):.5f}")

# Rank Transformations for ROC-AUC Optimization
oof_rank_lgb1 = rankdata(oof_lgb1) / len(oof_lgb1)
oof_rank_lgb2 = rankdata(oof_lgb2) / len(oof_lgb2)
oof_rank_cat  = rankdata(oof_cat)  / len(oof_cat)
oof_rank_xgb  = rankdata(oof_xgb)  / len(oof_xgb)

test_rank_lgb1 = rankdata(test_lgb1) / len(test_lgb1)
test_rank_lgb2 = rankdata(test_lgb2) / len(test_lgb2)
test_rank_cat  = rankdata(test_cat)  / len(test_cat)
test_rank_xgb  = rankdata(test_xgb)  / len(test_xgb)

# Optimize weights
weights_candidates = [
    (0.35, 0.20, 0.25, 0.20),
    (0.30, 0.25, 0.25, 0.20),
    (0.40, 0.20, 0.20, 0.20),
    (0.25, 0.25, 0.25, 0.25),
    (0.35, 0.15, 0.30, 0.20),
    (0.30, 0.20, 0.30, 0.20),
]

best_auc = 0.0
best_w = None
for w1, w2, w3, w4 in weights_candidates:
    blend_oof = w1 * oof_rank_lgb1 + w2 * oof_rank_lgb2 + w3 * oof_rank_cat + w4 * oof_rank_xgb
    score = roc_auc_score(y, blend_oof)
    if score > best_auc:
        best_auc = score
        best_w = (w1, w2, w3, w4)

print(f"\nBest Blend Weights: LGB1={best_w[0]}, LGB2={best_w[1]}, CAT={best_w[2]}, XGB={best_w[3]}")
print(f"===> ENSEMBLE OOF AUC: {best_auc:.5f} <===")

# Generate final test predictions
final_test_pred = (
    best_w[0] * test_rank_lgb1 +
    best_w[1] * test_rank_lgb2 +
    best_w[2] * test_rank_cat +
    best_w[3] * test_rank_xgb
)

# Output directory and save submission
output_dir = ROOT / 'output'
output_dir.mkdir(parents=True, exist_ok=True)
sub_file = output_dir / 'submission.csv'

sub = pd.DataFrame({
    'SK_ID_CURR': test_ids,
    'TARGET': final_test_pred
})
sub.to_csv(sub_file, index=False)
print(f"\nSubmission saved to: {sub_file}")
print("Sample submission rows:")
print(sub.head(10))
